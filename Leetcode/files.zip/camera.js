// ===== Camera: casts analytic rays in 1D/2D/3D screen configurations =====
// The object is ALWAYS rotated in full 4D, then perspective-divided w->3D->2D
// down to a projected 3D shape. `configuration` only changes how rays fan out
// on screen (1 axis, 2 axes, or full 2D screen + depth).

class Camera {
    constructor(canvas) {
        this.canvas = canvas;
        this.pos = v(0, 0, -5, 0);
        this.rot = v(0, 0, 0, 0); // camera's own look rotation (yaw/pitch), not object rotation
        this.configuration = "3D"; // "1D" | "2D" | "3D"
        this.maxCloudPoints = 200;
        this.fov = 90;
        this.aspect = canvas.width / canvas.height;
        this.near = 0.1;
        this.far = 100;
        this.f = 1 / Math.tan(this.fov * 0.5 * Math.PI / 180);
        this.wDistance = 5; // distance along w used for the 4D->3D perspective divide
    }

    // ---- Step 1: project the object's 4D world vertices down to camera-space 3D ----
    // Perspective divide by w first (4D->3D), then later by z (3D->2D) happens per-ray-test.
    projectTo3D(worldVertices) {
        const out = {};
        for (const id in worldVertices) {
            const p = worldVertices[id];
            // 4D perspective divide: treat w like a "depth" that recedes the xyz coords
            const wScale = this.wDistance / (this.wDistance + p.w || 1e-6);
            out[id] = v(p.x * wScale, p.y * wScale, p.z * wScale, 0);
        }
        return out;
    }

    // Camera-space transform: subtract camera pos, apply camera look rotation (yaw/pitch around x/y)
    toCameraSpace(p) {
        let rel = vSub(p, this.pos);
        rel = rotatePlane(rel, 'x', 'z', -this.rot.y); // yaw
        rel = rotatePlane(rel, 'y', 'z', -this.rot.x); // pitch
        return rel;
    }

    // ---- Ray generation ----
    // Returns an array of { origin, dir, screenX, screenY } rays depending on configuration.
    generateRays(resX, resY) {
        const rays = [];
        const tanHalfFov = Math.tan(this.fov * 0.5 * Math.PI / 180);

        if (this.configuration === "1D") {
            // Single scanline of rays varying only in screen-x, fixed screen-y = 0
            for (let i = 0; i < resX; i++) {
                const ndcX = (2 * (i + 0.5) / resX - 1) * tanHalfFov * this.aspect;
                const dir = vNorm(v(ndcX, 0, 1, 0));
                rays.push({ origin: v(0, 0, 0, 0), dir, screenX: i, screenY: 0 });
            }
        } else if (this.configuration === "2D") {
            // Rays fan over screen-x AND screen-y, but all at a fixed depth plane (orthographic-ish 2D fan)
            // True 2D raycasting: origin is camera pos, dir varies only in x/y plane (z component flattened)
            for (let i = 0; i < resX; i++) {
                const ndcX = (2 * (i + 0.5) / resX - 1) * tanHalfFov * this.aspect;
                const dir = vNorm(v(ndcX, 0, 1, 0)); // z is the "forward" axis of the 2D plane (x,z)
                rays.push({ origin: v(0, 0, 0, 0), dir, screenX: i, screenY: 0 });
            }
        } else { // "3D"
            for (let j = 0; j < resY; j++) {
                for (let i = 0; i < resX; i++) {
                    const ndcX = (2 * (i + 0.5) / resX - 1) * tanHalfFov * this.aspect;
                    const ndcY = (1 - 2 * (j + 0.5) / resY) * tanHalfFov;
                    const dir = vNorm(v(ndcX, ndcY, 1, 0));
                    rays.push({ origin: v(0, 0, 0, 0), dir, screenX: i, screenY: j });
                }
            }
        }
        return rays;
    }

    // ---- Ray vs segment (used for 1D point-crossing tests and 2D edge tests) ----
    // Ray: origin + t*dir (t>=0). Segment in the XZ plane (2D raycasting plane): a -> b.
    // Returns smallest valid t, or null.
    static rayVsSegment2D(origin, dir, a, b) {
        // Work in (x,z) plane
        const ox = origin.x, oz = origin.z;
        const dx = dir.x, dz = dir.z;
        const ax = a.x, az = a.z;
        const bx = b.x, bz = b.z;
        const sx = bx - ax, sz = bz - az;

        const denom = dx * sz - dz * sx;
        if (Math.abs(denom) < 1e-12) return null; // parallel

        const t = ((ax - ox) * sz - (az - oz) * sx) / denom;
        const u = ((ax - ox) * dz - (az - oz) * dx) / denom;

        if (t >= 0 && u >= 0 && u <= 1) return t;
        return null;
    }

    // ---- Ray vs triangle (Möller–Trumbore) ----
    static rayVsTriangle(origin, dir, p0, p1, p2) {
        const e1 = vSub(p1, p0);
        const e2 = vSub(p2, p0);
        const h = vCross3(dir, e2);
        const a = vDot(e1, h);
        if (Math.abs(a) < 1e-12) return null; // parallel

        const f = 1 / a;
        const s = vSub(origin, p0);
        const u = f * vDot(s, h);
        if (u < 0 || u > 1) return null;

        const q = vCross3(s, e1);
        const w = f * vDot(dir, q);
        if (w < 0 || u + w > 1) return null;

        const t = f * vDot(e2, q);
        return t > 1e-9 ? t : null;
    }

    // ---- Main entry point: cast all rays for current configuration against an object ----
    // object: RigidObject. Returns array of hit results aligned with generateRays() order.
    raycast(object, resX, resY = 1) {
        const worldVerts = object.getWorldVertices();
        const projected = this.projectTo3D(worldVerts); // 4D -> 3D (w divided out)

        // transform into camera space
        const camVerts = {};
        for (const id in projected) camVerts[id] = this.toCameraSpace(projected[id]);

        const rays = this.generateRays(resX, resY);
        const hits = [];

        if (this.configuration === "3D") {
            const tris = object.getTriangles();
            for (const ray of rays) {
                let closestT = Infinity;
                let hitTri = null;
                for (const [i0, i1, i2] of tris) {
                    const p0 = camVerts[i0], p1 = camVerts[i1], p2 = camVerts[i2];
                    if (!p0 || !p1 || !p2) continue;
                    const t = Camera.rayVsTriangle(ray.origin, ray.dir, p0, p1, p2);
                    if (t !== null && t < closestT) { closestT = t; hitTri = [i0, i1, i2]; }
                }
                hits.push(hitTri ? { screenX: ray.screenX, screenY: ray.screenY, t: closestT, tri: hitTri } : null);
            }
        } else {
            // 1D and 2D both raycast against edges in the XZ plane
            const edges = object.getEdges();
            for (const ray of rays) {
                let closestT = Infinity;
                let hitEdge = null;
                for (const [i0, i1] of edges) {
                    const p0 = camVerts[i0], p1 = camVerts[i1];
                    if (!p0 || !p1) continue;
                    const t = Camera.rayVsSegment2D(ray.origin, ray.dir, p0, p1);
                    if (t !== null && t < closestT) { closestT = t; hitEdge = [i0, i1]; }
                }
                hits.push(hitEdge ? { screenX: ray.screenX, screenY: ray.screenY, t: closestT, edge: hitEdge } : null);
            }
        }

        return hits;
    }
}

if (typeof module !== 'undefined') {
    module.exports = { Camera };
}
