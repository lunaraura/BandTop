// ===== Vector utilities (4D-capable, degrade gracefully to 3D/2D/1D) =====

const v = (x = 0, y = 0, z = 0, w = 0) => ({ x, y, z, w });

const vAdd = (a, b) => v(a.x + b.x, a.y + b.y, a.z + b.z, a.w + b.w);
const vSub = (a, b) => v(a.x - b.x, a.y - b.y, a.z - b.z, a.w - b.w);
const vScale = (a, s) => v(a.x * s, a.y * s, a.z * s, a.w * s);
const vDot = (a, b) => a.x * b.x + a.y * b.y + a.z * b.z + a.w * b.w;
const vLen = (a) => Math.sqrt(vDot(a, a));
const vNorm = (a) => {
    const l = vLen(a);
    return l > 1e-12 ? vScale(a, 1 / l) : v(0, 0, 0, 0);
};
const vCross3 = (a, b) => v(
    a.y * b.z - a.z * b.y,
    a.z * b.x - a.x * b.z,
    a.x * b.y - a.y * b.x,
    0
);
const vClone = (a) => v(a.x, a.y, a.z, a.w);
const vEquals = (a, b, eps = 1e-9) =>
    Math.abs(a.x - b.x) < eps && Math.abs(a.y - b.y) < eps &&
    Math.abs(a.z - b.z) < eps && Math.abs(a.w - b.w) < eps;

// 4D rotation: rotates in a single plane defined by two axis names ('x','y','z','w')
// Works for 3D rotation too (e.g. rotatePlane(p, 'x', 'z', angle) is a standard yaw)
function rotatePlane(p, axisA, axisB, angle) {
    const c = Math.cos(angle), s = Math.sin(angle);
    const out = vClone(p);
    const a = p[axisA], b = p[axisB];
    out[axisA] = a * c - b * s;
    out[axisB] = a * s + b * c;
    return out;
}

// Apply all 6 rotation planes in sequence. `rot` = {xy,xz,xw,yz,yw,zw} angles in radians.
function rotate4D(p, rot) {
    let out = p;
    if (rot.xy) out = rotatePlane(out, 'x', 'y', rot.xy);
    if (rot.xz) out = rotatePlane(out, 'x', 'z', rot.xz);
    if (rot.xw) out = rotatePlane(out, 'x', 'w', rot.xw);
    if (rot.yz) out = rotatePlane(out, 'y', 'z', rot.yz);
    if (rot.yw) out = rotatePlane(out, 'y', 'w', rot.yw);
    if (rot.zw) out = rotatePlane(out, 'z', 'w', rot.zw);
    return out;
}

if (typeof module !== 'undefined') {
    module.exports = { v, vAdd, vSub, vScale, vDot, vLen, vNorm, vCross3, vClone, vEquals, rotatePlane, rotate4D };
}
