// ===== Renderer: draws raycast hits to the 2D canvas context =====

function renderHits(ctx, canvas, hits, configuration, resX, resY) {
    ctx.fillStyle = '#0a0e14';
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    if (configuration === "3D") {
        const cellW = canvas.width / resX;
        const cellH = canvas.height / resY;
        let maxT = 1;
        for (const h of hits) if (h && h.t < Infinity) maxT = Math.max(maxT, h.t);

        for (const h of hits) {
            if (!h) continue;
            const shade = Math.max(0, 1 - h.t / maxT);
            const g = Math.floor(60 + shade * 195);
            ctx.fillStyle = `rgb(${Math.floor(g*0.3)}, ${g}, ${Math.floor(g*0.85)})`;
            ctx.fillRect(h.screenX * cellW, h.screenY * cellH, cellW + 1, cellH + 1);
        }
    } else {
        // 1D and 2D: draw as a horizontal strip of hit/miss + depth shading
        const cellW = canvas.width / resX;
        const stripH = configuration === "1D" ? canvas.height : canvas.height * 0.5;
        const stripY = configuration === "1D" ? 0 : canvas.height * 0.25;

        let maxT = 1;
        for (const h of hits) if (h && h.t < Infinity) maxT = Math.max(maxT, h.t);

        for (let i = 0; i < hits.length; i++) {
            const h = hits[i];
            if (!h) continue;
            const shade = Math.max(0, 1 - h.t / maxT);
            const g = Math.floor(60 + shade * 195);
            ctx.fillStyle = `rgb(${Math.floor(g*0.3)}, ${g}, ${Math.floor(g*0.85)})`;
            ctx.fillRect(i * cellW, stripY, cellW + 1, stripH);
        }

        ctx.strokeStyle = '#2a3340';
        ctx.strokeRect(0, stripY, canvas.width, stripH);
    }
}

if (typeof module !== 'undefined') {
    module.exports = { renderHits };
}
