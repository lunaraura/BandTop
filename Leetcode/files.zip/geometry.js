// ===== Geometry: vertex maps + derived edges/faces =====
// Each shape is defined purely by its vertices (coords in {-1,1}).
// Edges and faces are DERIVED programmatically so this generalizes to any dimension.

const squareMap = {
    0: v(-1, -1, -1, -1), 1: v(1, -1, -1, -1), 2: v(1, 1, -1, -1), 3: v(-1, 1, -1, -1),
    4: v(-1, -1, 1, -1), 5: v(1, -1, 1, -1), 6: v(1, 1, 1, -1), 7: v(-1, 1, 1, -1),
    8: v(-1, -1, 1, 1), 9: v(1, -1, 1, 1), 10: v(1, 1, 1, 1), 11: v(-1, 1, 1, 1),
    12: v(-1, -1, -1, 1), 13: v(1, -1, -1, 1), 14: v(1, 1, -1, 1), 15: v(-1, 1, -1, 1),
};

// Active axes per configuration: 1D uses x, 2D uses x/y, 3D uses x/y/z, 4D uses x/y/z/w
const AXES = { "1D": ['x'], "2D": ['x', 'y'], "3D": ['x', 'y', 'z'], "4D": ['x', 'y', 'z', 'w'] };

function coordsOf(p, axes) { return axes.map(ax => p[ax]); }

// Two vertices are connected by an edge iff they differ in exactly one active axis.
function deriveEdges(vertexMap, axes) {
    const ids = Object.keys(vertexMap).map(Number);
    const seen = new Set();
    const edges = [];
    for (let i = 0; i < ids.length; i++) {
        for (let j = i + 1; j < ids.length; j++) {
            const a = coordsOf(vertexMap[ids[i]], axes);
            const b = coordsOf(vertexMap[ids[j]], axes);
            let diffCount = 0;
            for (let k = 0; k < a.length; k++) if (Math.abs(a[k] - b[k]) > 1e-9) diffCount++;
            if (diffCount === 1) {
                const key = `${ids[i]}-${ids[j]}`;
                if (!seen.has(key)) { seen.add(key); edges.push([ids[i], ids[j]]); }
            }
        }
    }
    return edges;
}

// A quad face: 4 vertices that agree on all-but-2 active axes, and those 2 axes
// take all 4 combinations of {-1,1}. We find them by grouping on the "fixed" axes.
function deriveFaces(vertexMap, axes) {
    if (axes.length < 3) return []; // faces only meaningful in 3D+
    const ids = Object.keys(vertexMap).map(Number);
    const faces = [];
    const n = axes.length;

    // choose every pair of "free" axes; remaining axes are "fixed"
    for (let f1 = 0; f1 < n; f1++) {
        for (let f2 = f1 + 1; f2 < n; f2++) {
            const fixedAxes = axes.filter((_, idx) => idx !== f1 && idx !== f2);
            // group vertices by their fixed-axis signature
            const groups = new Map();
            for (const id of ids) {
                const p = vertexMap[id];
                const sig = fixedAxes.map(ax => p[ax].toFixed(3)).join(',');
                if (!groups.has(sig)) groups.set(sig, []);
                groups.get(sig).push(id);
            }
            for (const group of groups.values()) {
                if (group.length !== 4) continue;
                // order the 4 vertices into a proper quad loop (CCW-ish) via angle around centroid
                const pts = group.map(id => ({ id, p: vertexMap[id] }));
                const cx = pts.reduce((s, o) => s + o.p[axes[f1]], 0) / 4;
                const cy = pts.reduce((s, o) => s + o.p[axes[f2]], 0) / 4;
                pts.sort((a, b) => {
                    const angA = Math.atan2(a.p[axes[f2]] - cy, a.p[axes[f1]] - cx);
                    const angB = Math.atan2(b.p[axes[f2]] - cy, b.p[axes[f1]] - cx);
                    return angA - angB;
                });
                faces.push(pts.map(o => o.id));
            }
        }
    }
    return faces;
}

// Triangulate a quad face (fan triangulation: [0,1,2] and [0,2,3])
function triangulateFace(face) {
    const tris = [];
    for (let i = 1; i + 1 < face.length; i++) {
        tris.push([face[0], face[i], face[i + 1]]);
    }
    return tris;
}

class RigidObject {
    constructor(vertexMap = squareMap) {
        this.pos = v(0, 0, 0, 0);
        this.rot = { xy: 0, xz: 0, xw: 0, yz: 0, yw: 0, zw: 0 };
        this.scale = v(1, 1, 1, 1);
        this.vertexMap = vertexMap;

        // Pre-derive topology at full 4D resolution; consumers slice down as needed per config.
        this._edges4D = deriveEdges(vertexMap, AXES["4D"]);
        this._faces4D = deriveFaces(vertexMap, AXES["4D"]);
    }

    // Returns world-space (rotated/scaled/translated) vertex map, still 4D.
    getWorldVertices() {
        const out = {};
        for (const id in this.vertexMap) {
            let p = this.vertexMap[id];
            p = v(p.x * this.scale.x, p.y * this.scale.y, p.z * this.scale.z, p.w * this.scale.w);
            p = rotate4D(p, this.rot);
            p = vAdd(p, this.pos);
            out[id] = p;
        }
        return out;
    }

    getEdges() { return this._edges4D; }
    getFaces() { return this._faces4D; }
    getTriangles() { return this._faces4D.flatMap(triangulateFace); }
}

if (typeof module !== 'undefined') {
    module.exports = { squareMap, AXES, deriveEdges, deriveFaces, triangulateFace, RigidObject };
}
